select * from tmdb_data;

create table tmbd_copy
as
(select * from tmdb_data);

select * from tmbd_copy;



-- create table tmdb_data_2
-- as
-- select *, year(release_date) as release_year, month(release_date) as release_month 
-- from tmdb_data;


-- drop table tmdb_data;

-- create table tmdb_data
-- as
-- select * from tmdb_data_2;

